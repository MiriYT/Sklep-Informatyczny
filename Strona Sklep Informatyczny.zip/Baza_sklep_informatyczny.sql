-- Ustawienia sesji
SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

-- Tworzenie tabel
CREATE TABLE public.klienci (
    idklienta integer NOT NULL,
    imie character varying(25),
    nazwisko character varying(25),
    telefon character varying(25)
);

CREATE TABLE public.pracownicy (
    idpracownika integer NOT NULL,
    imie character varying(25),
    nazwisko character varying(25),
    specjalizacja character varying(50),
    login character varying(25)
);

CREATE TABLE public.produkty (
    idproduktu integer NOT NULL,
    nazwa character varying(100),
    rok_produkcji character(4),
    cena numeric(10,2),
    dostepnosc character varying(20),
    CONSTRAINT produkty_dostepnosc_check CHECK (dostepnosc IN ('dostępne', 'niedostępne'))
);

CREATE TABLE public.recenzje (
    idklienta integer,
    idproduktu integer,
    ocena integer,
    komentarz character varying(255)
);

CREATE TABLE public.serwis (
    idpracownika integer,
    idproduktu integer,
    nazwa_produktu character varying(255),
    rozpoczecie date,
    zakonczenie date,
    kwota_brutto_pln numeric(10,2)
);

CREATE TABLE public.zamowienia (
    idzamowienia integer NOT NULL,
    idklienta integer,
    idproduktu integer,
    data_zamowienia date
);

-- Tworzenie sekwencji
CREATE SEQUENCE public.klienci_idklienta_seq START 1;
CREATE SEQUENCE public.pracownicy_idpracownika_seq START 1;
CREATE SEQUENCE public.produkty_idproduktu_seq START 1;
CREATE SEQUENCE public.zamowienia_idzamowienia_seq START 1;

-- Przypisanie sekwencji jako domyślne wartości
ALTER TABLE public.klienci ALTER COLUMN idklienta SET DEFAULT nextval('public.klienci_idklienta_seq');
ALTER TABLE public.pracownicy ALTER COLUMN idpracownika SET DEFAULT nextval('public.pracownicy_idpracownika_seq');
ALTER TABLE public.produkty ALTER COLUMN idproduktu SET DEFAULT nextval('public.produkty_idproduktu_seq');
ALTER TABLE public.zamowienia ALTER COLUMN idzamowienia SET DEFAULT nextval('public.zamowienia_idzamowienia_seq');

-- Tworzenie widoków
CREATE VIEW public.klienci_ktorzy_dali_ocene_5 AS
SELECT k.imie, k.nazwisko, p.nazwa, r.ocena, r.komentarz
FROM public.klienci k
JOIN public.recenzje r ON k.idklienta = r.idklienta
JOIN public.produkty p ON p.idproduktu = r.idproduktu
WHERE r.ocena = 5;

CREATE VIEW public.slabe_opinie AS
SELECT k.imie, k.nazwisko, p.nazwa, r.ocena, r.komentarz
FROM public.klienci k
JOIN public.recenzje r ON k.idklienta = r.idklienta
JOIN public.produkty p ON p.idproduktu = r.idproduktu
WHERE r.ocena <= 3;

CREATE VIEW public.pracownik_od_komputerow AS
SELECT pr.idpracownika, pr.imie, pr.nazwisko, s.nazwa_produktu
FROM public.pracownicy pr
JOIN public.serwis s ON pr.idpracownika = s.idpracownika
WHERE pr.specjalizacja = 'komputery';

-- Wstawianie danych do tabel
INSERT INTO public.klienci (idklienta, imie, nazwisko, telefon) VALUES
(1, 'Jan', 'Kowalski', '123456789'),
(2, 'Anna', 'Nowak', '987654321'),
(3, 'Piotr', 'Zielinski', '456789123'),
(4, 'Maria', 'Wiśniewska', '321654987'),
(5, 'Tomasz', 'Szymański', '741258963'),
(6, 'Karolina', 'Lewandowska', '852963741'),
(7, 'Marek', 'Kamiński', '369258147'),
(8, 'Kamil', 'Bartosz', '600111222'),
(9, 'Wiktoria', 'Pirlo', '456123789');

INSERT INTO public.pracownicy (idpracownika, imie, nazwisko, specjalizacja, login) VALUES
(1, 'Piotr', 'Wiśniewski', 'telefony', 'p.wisniewski'),
(2, 'Katarzyna', 'Zalewska', 'komputery', 'k.zalewska'),
(3, 'Marek', 'Nowakowski', 'rtv', 'm.nowakowski'),
(4, 'Adam', 'Szczepan', 'konsole', 'a.szczepan'),
(5, 'Ewa', 'Stolarz', 'telefony', 'e.stolarz'),
(6, 'Tomasz', 'Kowalczyk', 'komputery', 't.kowalczyk'),
(7, 'Barbara', 'Wójcik', 'rtv', 'b.wojcik');

INSERT INTO public.produkty (idproduktu, nazwa, rok_produkcji, cena, dostepnosc) VALUES
(1, 'iPhone 13', '2021', 4999.99, 'dostępne'),
(2, 'Dell XPS 13', '2022', 5499.00, 'dostępne'),
(3, 'Samsung QLED TV', '2023', 3499.99, 'dostępne'),
(4, 'PS5', '2021', 2499.00, 'dostępne'),
(5, 'Samsung Galaxy S21', '2021', 3799.99, 'dostępne'),
(6, 'Lenovo ThinkPad', '2023', 4999.00, 'dostępne'),
(7, 'LG OLED TV', '2023', 4999.99, 'niedostępne'),
(8, 'HyperPC Ultra X', '2024', 8999.99, 'dostępne'),
(9, 'iPhone 15 Pro', '2023', 5700.99, 'niedostępne'),
(10, 'PS4', '2013', 1000.00, 'dostępne');

INSERT INTO public.recenzje (idklienta, idproduktu, ocena, komentarz) VALUES
(1, 1, 5, 'Świetny telefon, bardzo szybki!'),
(2, 2, 4, 'Bardzo dobra jakość, ale mógłby być tańszy'),
(3, 3, 5, 'Fantastyczny obraz, uwielbiam ten telewizor!'),
(4, 4, 3, 'Działa dobrze, ale trochę za głośno w trybie gamingowym'),
(5, 5, 5, 'Bardzo zadowolony, szybki i niezawodny!'),
(6, 6, 4, 'Dobry laptop, ale ma mało portów USB'),
(7, 7, 5, 'Jakość obrazu jest niesamowita, polecam!'),
(8, 8, 2, 'lekko porysowany ale działa oraz słaba bateria'),
(1, 9, 5, 'Wszystko działa prawidłowo, szybka dostawa oraz super obsługa przez telefon'),
(3, 2, 3, 'Laptop działa ale cena za duża'),
(9, 10, 5, 'Super konsola, pomimo lat nadal się super sprawuje');

INSERT INTO public.serwis (idpracownika, idproduktu, nazwa_produktu, rozpoczecie, zakonczenie, kwota_brutto_pln) VALUES
(1, 1, 'iPhone 13', '2025-10-01', '2025-10-05', 150.00),
(2, 2, 'Dell XPS 13', '2025-10-02', '2025-10-06', 200.00),
(3, 3, 'Samsung QLED TV', '2025-10-03', '2025-10-07', 300.00),
(4, 4, 'PS5', '2025-10-04', '2025-10-08', 100.00),
(5, 5, 'Samsung Galaxy S21', '2025-10-05', '2025-10-09', 120.00),
(6, 6, 'Lenovo ThinkPad', '2025-10-06', '2025-10-10', 250.00),
(7, 7, 'LG OLED TV', '2025-10-07', '2025-10-11', 400.00);

INSERT INTO public.zamowienia (idzamowienia, idklienta, idproduktu, data_zamowienia) VALUES
(1, 1, 1, '2025-11-01'),
(2, 2, 2, '2025-11-02'),
(3, 3, 3, '2025-11-03'),
(4, 4, 4, '2025-11-04'),
(5, 5, 5, '2025-11-05'),
(6, 6, 6, '2025-11-06'),
(7, 7, 7, '2025-11-07'),
(8, 8, 8, '2025-11-21'),
(9, 6, 10, '2025-12-02'),
(10, 9, 10, '2025-12-23');

-- Ustawienie wartości sekwencji na aktualne
SELECT setval('public.klienci_idklienta_seq', 9, true);
SELECT setval('public.pracownicy_idpracownika_seq', 7, true);
SELECT setval('public.produkty_idproduktu_seq', 10, true);
SELECT setval('public.zamowienia_idzamowienia_seq', 10, true);

-- Klucze główne
ALTER TABLE public.klienci ADD CONSTRAINT klienci_pkey PRIMARY KEY (idklienta);
ALTER TABLE public.pracownicy ADD CONSTRAINT pracownicy_pkey PRIMARY KEY (idpracownika);
ALTER TABLE public.produkty ADD CONSTRAINT produkty_pkey PRIMARY KEY (idproduktu);
ALTER TABLE public.zamowienia ADD CONSTRAINT zamowienia_pkey PRIMARY KEY (idzamowienia);

-- Klucze obce
ALTER TABLE public.recenzje ADD CONSTRAINT recenzje_idklienta_fkey FOREIGN KEY (idklienta) REFERENCES public.klienci(idklienta) ON UPDATE CASCADE ON DELETE CASCADE;
ALTER TABLE public.recenzje ADD CONSTRAINT recenzje_idproduktu_fkey FOREIGN KEY (idproduktu) REFERENCES public.produkty(idproduktu) ON UPDATE CASCADE ON DELETE CASCADE;
ALTER TABLE public.serwis ADD CONSTRAINT serwis_idpracownika_fkey FOREIGN KEY (idpracownika) REFERENCES public.pracownicy(idpracownika) ON UPDATE CASCADE ON DELETE CASCADE;
ALTER TABLE public.serwis ADD CONSTRAINT serwis_idproduktu_fkey FOREIGN KEY (idproduktu) REFERENCES public.produkty(idproduktu) ON UPDATE CASCADE ON DELETE CASCADE;
ALTER TABLE public.zamowienia ADD CONSTRAINT zamowienia_idklienta_fkey FOREIGN KEY (idklienta) REFERENCES public.klienci(idklienta) ON UPDATE CASCADE ON DELETE CASCADE;
ALTER TABLE public.zamowienia ADD CONSTRAINT zamowienia_idproduktu_fkey FOREIGN KEY (idproduktu) REFERENCES public.produkty(idproduktu) ON UPDATE CASCADE ON DELETE CASCADE;

-- Uprawnienia
REVOKE USAGE ON SCHEMA public FROM PUBLIC;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.klienci TO worker;
GRANT SELECT ON TABLE public.produkty TO client;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.produkty TO worker;
GRANT SELECT,UPDATE ON TABLE public.recenzje TO client;
GRANT SELECT ON TABLE public.recenzje TO worker;
GRANT SELECT ON TABLE public.pracownicy TO worker;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.serwis TO worker;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.pracownik_od_komputerow TO worker;
GRANT SELECT,INSERT ON TABLE public.zamowienia TO worker;
