<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sklep Informatyczny</title>
    <link rel="shortcut icon" href="logo.png"></link>
</head>
<style>
    * {
        font-family: arial;
    } html, body{
        background-color: #E1D9D1;
        height: 100%;
        width: 100%;
        margin: 0;
        padding: 0;
        position: absolute;
        flex-grow: 1;
        overflow: hidden;

    } header {
        background: linear-gradient(to right, cyan, lightblue, lightblue, blue);
        float: left;
        width: 100%;
        height: 10%;
        font-family: "Harlow Solid Italic", serif;
        font-style: italic;
    } footer {
        text-align: right;
        justify-content: space-between;
        background: linear-gradient(to left, cyan, lightblue, lightblue, blue);
        font-size: small;
        float: left;
        width: 100%;
        height: 15%; 
        margin-top: auto;
        bottom: 0;
        display: flex;
    }  #left {
        width: 20%;
        float: left;
        background-color: #E1D9D1;
        height: 75%;
    } #right {
        width: 78%;
        float: right;
        background-color: lightgray;
        height: calc(75% - 20px);
        overflow-y: auto;
        overflow-x: hidden;
    } #zbedny {
        width: 2%;
        background-color: lightgray;
        height: 75%;
        float: left;
    } #p {
        text-align: center;
        font-size: 25px;
        font-weight: bold;
    } #opis {
        font-size: 17px;
        text-indent: 20px;
        margin: 2px;
    }     
</style>    
<body>
    <header>
    <h1 style="text-align: center;">Strona o sklepie Informatycznym</h1>
</header>
<div id=left>
    <ul>
    <h4 style="text-align: left;">Kategorie:</h4>
    <li><a href="index.php">Strona główna</a></li>
    <li><a href="pracownicy.php">Pracownicy</a></li>
    <li><a href="produkty.php">Produkty</a></li>
    <li><a href="zamowienia.php">Zamówienia</a></li>
    <li><a href="recenzje.php">Recenzje</a></li>
</ul>
</div>
<div id=zbedny></div>
<div id=right>
    <p id=p>KatoTech - sklep i serwis informatyczny</p>
<p id="opis">      <b>KatoTech</b> to dynamicznie rozwijająca się firma z serca Śląska, specjalizująca się w sprzedaży komputerów, sprzętu RTV, telefonów oraz konsol gamingowych.
    W naszej ofercie znajdują się zarówno najnowsze modele urządzeń, jak i sprawdzone rozwiązania dla klientów szukających najlepszego stosunku jakości do ceny.
    Stawiamy na szeroki wybór produktów oraz profesjonalne doradztwo, pomagając dobrać sprzęt dopasowany do indywidualnych potrzeb – od pracy biurowej i nauki,
    po zaawansowane zastosowania i rozrywkę. <br>
</p><p id="opis">Oprócz sprzedaży prowadzimy również kompleksowy serwis komputerowy, oferując diagnostykę, naprawy, modernizacje oraz instalację oprogramowania.
    Zespół KatoTech to doświadczeni specjaliści, którzy dbają o szybkie i rzetelne wykonanie każdej usługi. Obsługujemy zarówno klientów indywidualnych, jak i firmy na terenie całego Śląska,
    zapewniając wsparcie techniczne na wysokim poziomie. <br>
</p><p id="opis">Naszym priorytetem jest jakość, zaufanie oraz satysfakcja klientów, dlatego stale poszerzamy ofertę i podnosimy standard obsługi.
     W KatoTech każdy znajdzie sprzęt i pomoc dopasowaną do swoich oczekiwań.</p>
    <iframe style="width: 98%; height: 60%;" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3047.2807190386006!2d19.010734377025663!3d50.28522557156115!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4716d1e3e9d16e75%3A0xf4d15f9de0d8e0b1!2sKar%C5%82owicza%2067%2C%2040-145%20Katowice!5e1!3m2!1spl!2spl!4v1763705618094!5m2!1spl!2spl" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe> 
</div>
<footer id='stopa'>
        <img src="logo.png"></img>
<?php
    $serwer = "localhost";
    $user = "postgres";
    $pass = "Admin123"; 
    $dbname = "Sklep_informatyczny";
    $idpolaczenia = pg_connect("host=$serwer dbname=$dbname user=$user password=$pass");
    
    $zapytanie_ocena="select round(avg(ocena),1) as ocena from recenzje";
    $wynik_ocena = pg_query($idpolaczenia, $zapytanie_ocena);
    while($o = pg_fetch_array($wynik_ocena)){ 
        echo "<p id=p>Średnia Opini: ".$o['ocena']."</p>";
        }
    pg_close($idpolaczenia);
?>
    <div>
        <h4>Dane kontakowe</h4>
        <p><b>Adres: </b>Katowice 40-145 ul. Karłowicza 67/121</p>
        <p><b>Telefon: </b>123 456 789</p>
        <p><b>E-mail: </b><a href="mailto:sklep@informatyk.pl">KatoTech@informatyk.pl</a></p><br>
    </div>
</footer>
</body>
</html>