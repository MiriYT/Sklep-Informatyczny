<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sklep Informatyczny</title>
    <link rel="shortcut icon" href="logo.png"></link>
</head>
<style>
    * {
        font-family: arial;
    } html, body{
        background-color: #E1D9D1;
        height: 100%;
        width: 100%;
        margin: 0;
        padding: 0;
        position: absolute;
        flex-grow: 1;
        overflow: hidden;

    } header {
        background: linear-gradient(to right, cyan, lightblue, lightblue, blue);
        float: left;
        width: 100%;
        height: 10%;
        font-family: "Harlow Solid Italic", serif;
        font-style: italic;
    } footer {
        text-align: right;
        justify-content: space-between;
        background: linear-gradient(to left, cyan, lightblue, lightblue, blue);
        font-size: small;
        float: left;
        width: 100%;
        height: 15%; 
        margin-top: auto;
        bottom: 0;
        display: flex;
    }  #left {
        width: 20%;
        float: left;
        background-color: #E1D9D1;
        height: 75%;
    } #right {
        width: 78%;
        float: right;
        background-color: lightgray;
        height: calc(75% - 20px);
        overflow-y: auto;
        overflow-x: hidden;
    } #zbedny {
        width: 2%;
        background-color: lightgray;
        height: 75%;
        float: left;
    } table {
        border: 1px solid black;
        border-collapse: collapse;
        text-align: center;
        width: 98%;
        
    }  table, td, tr {
        border: 1px solid black;
        border-collapse: collapse;
        text-align: center;
    } #p {
        text-align: center;
        font-size: 25px;
        font-weight: bold;
    }      
</style>    
<body>
    <header>
    <h1 style="text-align: center;">Strona o sklepie Informatycznym</h1>
</header>
<div id=left>
    <ul>
    <h4 style="text-align: left;">Kategorie:</h4>
    <li><a href="index.php">Strona główna</a></li>
    <li><a href="pracownicy.php">Pracownicy</a></li>
    <li><a href="produkty.php">Produkty</a></li>
    <li><a href="zamowienia.php">Zamówienia</a></li>
    <li><a href="recenzje.php">Recenzje</a></li>
</ul>
</div>
<div id=zbedny></div>
<div id=right>
<?php    
    $serwer = "localhost";
    $user = "postgres";
    $pass = "Admin123"; 
    $dbname = "Sklep_informatyczny"; 
    $idpolaczenia = pg_connect("host=$serwer dbname=$dbname user=$user password=$pass");
    $zapytanie = "select * from pracownicy"; 
    $wynik_zapytania = pg_query($idpolaczenia, $zapytanie); 
        echo "<p id=p>Pracownicy Sklepu</p>";
        echo "<table id=pracownicy>
        <tr>
            <td><b>Imię</b></td>
            <td><b>Nazwisko</b></td>
            <td><b>Specjalizacja</b></td>            
        </tr>";
        while($i = pg_fetch_array($wynik_zapytania)){ 
        echo "<tr>
            <td>",$i['imie'],"</td>
            <td>",$i['nazwisko'],"</td>
            <td>",$i['specjalizacja'],"</td>            
        </tr>";} 
    echo "</table>"; 
    echo "<hr>"; 
    echo "<h2 id=p>Wyszukaj pracownika: </h2>"; 
    @$filtr = $_POST['tekst1'];
    @$dane = $_POST['tekst2'];

if ($filtr && $dane) {
    $dozwolone = ["imie", "nazwisko", "specjalizacja", "login"];
    $zapytanie_pracownik = "SELECT * FROM pracownicy WHERE $filtr LIKE '%$dane%';";
    $wynik_pracownik = pg_query($idpolaczenia, $zapytanie_pracownik);
    if (!$wynik_pracownik || pg_num_rows($wynik_pracownik) == 0) {
        die("<p>Brak lub błąd danych</p><br><a href=pracownicy.php>Powrót</a>");
    }
    echo "<table id=pracownicy>
            <tr>
                <td><b>Imię</b></td>
                <td><b>Nazwisko</b></td>
                <td><b>Specjalizacja</b></td>
                <td><b>Login</b></td>
            </tr>";
    while($i = pg_fetch_array($wynik_pracownik)){ 
        echo "<tr>
                <td>{$i['imie']}</td>
                <td>{$i['nazwisko']}</td>
                <td>{$i['specjalizacja']}</td>
                <td>{$i['login']}</td>
            </tr>";
    }
    echo "</table>";
}
        pg_close($idpolaczenia); 
?>
<br>
    <form method="POST" action="pracownicy.php">
    Co chcesz wyszukać:    <select name="tekst1">
  <option value="imie">imie</option>
  <option value="nazwisko">nazwisko</option>
  <option value="specjalizacja">specjalizacja</option>
  <option value="login">login</option>
</select>
    | Dane: <input type="text" name="tekst2" required>
    | <input type="submit" value="Wyszukaj">
</form>  
</div>
<footer id='stopa'>
        <img src="logo.png"></img>
        <?php
    $idpolaczenia = pg_connect("host=$serwer dbname=$dbname user=$user password=$pass");
    $zapytanie_ocena="select round(avg(ocena),1) as ocena from recenzje";
    $wynik_ocena = pg_query($idpolaczenia, $zapytanie_ocena);
    while($o = pg_fetch_array($wynik_ocena)){ 
        echo "<p id=p>Średnia Opini: ".$o['ocena']."</p>";
        }
    pg_close($idpolaczenia);
?>
    <div>
        <h4>Dane kontakowe</h4>
        <p><b>Adres: </b>Katowice 40-145 ul. Karłowicza 67/121</p>
        <p><b>Telefon: </b>123 456 789</p>
        <p><b>E-mail: </b><a href="mailto:sklep@informatyk.pl">KatoTech@informatyk.pl</a></p><br>
    </div>
</footer>
</body>
</html>