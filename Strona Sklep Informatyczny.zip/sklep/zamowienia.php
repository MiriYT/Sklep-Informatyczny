<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sklep Informatyczny</title>
    <link rel="shortcut icon" href="logo.png"></link>
</head>
<style>
    * {
        font-family: arial;
    } html, body{
        background-color: #E1D9D1;
        height: 100%;
        width: 100%;
        margin: 0;
        padding: 0;
        position: absolute;
        flex-grow: 1;
        overflow: hidden;

    } header {
        background: linear-gradient(to right, cyan, lightblue, lightblue, blue);
        float: left;
        width: 100%;
        height: 10%;
        font-family: "Harlow Solid Italic", serif;
        font-style: italic;
    } footer {
        text-align: right;
        justify-content: space-between;
        background: linear-gradient(to left, cyan, lightblue, lightblue, blue);
        font-size: small;
        float: left;
        width: 100%;
        height: 15%; 
        margin-top: auto;
        bottom: 0;
        display: flex;
    }  #left {
        width: 20%;
        float: left;
        background-color: #E1D9D1;
        height: 75%;
    } #right {
        width: 78%;
        float: right;
        background-color: lightgray;
        height: calc(75% - 20px);
        overflow-y: auto;
        overflow-x: hidden;
    } #zbedny {
        width: 2%;
        background-color: lightgray;
        height: 75%;
        float: left;
    } #p {
        text-align: center;
        font-size: 25px;
        font-weight: bold;
    } #opis {
        font-family: "Segoe UI", Arial, sans-serif;
        font-size: 16px;
        text-align: center;
    } table {
        border: 1px solid black;
        border-collapse: collapse;
        text-align: center;
        margin: 0 auto;
        
    }  table, td, tr {
        border: 1px solid black;
        border-collapse: collapse;
        text-align: center;
    }       
</style>    
<body>
    <header>
    <h1 style="text-align: center;">Strona o sklepie Informatycznym</h1>
</header>
<div id=left>
    <ul>
    <h4 style="text-align: left;">Kategorie:</h4>
    <li><a href="index.php">Strona główna</a></li>
    <li><a href="pracownicy.php">Pracownicy</a></li>
    <li><a href="produkty.php">Produkty</a></li>
    <li><a href="zamowienia.php">Zamówienia</a></li>
    <li><a href="recenzje.php">Recenzje</a></li>
</ul>
</div>
<div id=zbedny></div>
<div id=right>
<?php
    $serwer = "localhost";
    $user = "postgres";
    $pass = "Admin123";
    $dbname = "Sklep_informatyczny";
    $idpolaczenia = pg_connect("host=$serwer dbname=$dbname user=$user password=$pass");

echo "<h2 id=p>Dodaj zamówienie</h2>";

@$imie = $_POST['tekst1'];
@$nazwisko = $_POST['tekst2'];
@$nazwa = $_POST['tekst3'];
@$data = $_POST['tekst4'];
@$telefon = $_POST['tekst5'];

if ($imie && $nazwisko && $nazwa && $data) {
    $zapytanie_klient = pg_query($idpolaczenia,"SELECT idklienta FROM klienci WHERE imie='$imie' AND nazwisko='$nazwisko' LIMIT 1");
    $klient = pg_fetch_array($zapytanie_klient);

    if (!$klient) {
        if (!$telefon) {
            echo "<p><b>Podaj telefon, bo klient nie istnieje.</b></p>";
            pg_close($idpolaczenia);
        }
        pg_query($idpolaczenia, "INSERT INTO klienci(imie,nazwisko,telefon) VALUES ('$imie','$nazwisko','$telefon')");
        $zapytanie_klient = pg_query($idpolaczenia, "SELECT idklienta FROM klienci WHERE imie='$imie' AND nazwisko='$nazwisko' LIMIT 1");
        $klient = pg_fetch_array($zapytanie_klient);
    }
    $idklienta = $klient['idklienta'];

    $zapytanie_produkt = pg_query($idpolaczenia, "SELECT idproduktu FROM produkty WHERE nazwa='$nazwa' LIMIT 1");
    $produkt = pg_fetch_array($zapytanie_produkt);

    if (!$produkt) {
        echo "<p><b>Błąd:</b> Produkt nie istnieje.</p>";
        pg_close($idpolaczenia);
    }
    $idproduktu = $produkt['idproduktu'];
    pg_query($idpolaczenia, "INSERT INTO zamowienia(idklienta,idproduktu,data_zamowienia) VALUES ($idklienta,$idproduktu,'$data')");
    echo "<p><b>Dodano zamówienie!</b></p>";
}

pg_close($idpolaczenia);
?>
<form method="POST" action="zamowienia.php">
Imię: <input type="text" name="tekst1"> |
Nazwisko: <input type="text" name="tekst2" > |
Telefon Kontaktowy: <input type="text" name="tekst5"> |
Produkt: <input type="text" name="tekst3" size=10> |
Data: <input type="date" name="tekst4"> |
<input type="submit" value="Dodaj zamówienie">
</form>
<hr>
<table>
    <tr>
    <td><a href="produkty.php">Zobacz produkty</td>
    </tr>
</table>
<hr>
<p id=p>Informacja o przetwarzaniu danych</p>

<p id=opis>Administratorem danych jest KatoTech, ul. Karłowicza 67/121, 40-145 Katowice. Kontakt: KatoTech@informatyk.pl, tel. 123 456 789.</p>

<p id=opis>Dane podawane podczas składania zamówienia (imię, nazwisko, telefon, nazwa produktu, data zamówienia) są przetwarzane wyłącznie w celu realizacji zamówienia oraz kontaktu z klientem. Podstawą przetwarzania jest wykonanie umowy.</p>

<p id=opis>Dane mogą być przekazywane tylko podmiotom obsługującym księgowość, hosting oraz – jeśli dotyczy – firmom realizującym dostawę. Nie udostępniamy danych w celach marketingowych.</p>

<p id=opis>Dane przechowujemy przez okres wymagany przepisami księgowymi oraz do czasu przedawnienia ewentualnych roszczeń.</p>
<p id=opis>Masz prawo do dostępu do swoich danych, ich poprawienia, usunięcia, ograniczenia przetwarzania lub złożenia skargi do Prezesa UODO.</p>

<p id=opis>Dane nie są profilowane ani automatycznie oceniane.</p>
</div>
<footer id='stopa'>
        <img src="logo.png"></img>
<?php
    $idpolaczenia = pg_connect("host=$serwer dbname=$dbname user=$user password=$pass");
    $zapytanie_ocena="select round(avg(ocena),1) as ocena from recenzje";
    $wynik_ocena = pg_query($idpolaczenia, $zapytanie_ocena);
    while($o = pg_fetch_array($wynik_ocena)){ 
        echo "<p id=p>Średnia Opini: ".$o['ocena']."</p>";
        }
    pg_close($idpolaczenia);
?>
    <div>
        <h4>Dane kontakowe</h4>
        <p><b>Adres: </b>Katowice 40-145 ul. Karłowicza 67/121</p>
        <p><b>Telefon: </b>123 456 789</p>
        <p><b>E-mail: </b><a href="mailto:sklep@informatyk.pl">KatoTech@informatyk.pl</a></p><br>
    </div>
</footer>
</body>
</html>